<?
$db=mysqli_connect('localhost','getsellw_trx1','Mk$786143','getsellw_trx1');
if(!$db){echo "Data Base Not Connected"; }
////////////////////////////////////////

////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////
////// for api id
$forapiid = '19028';
////// for api password
$forapipass = 'AUedBoE3lzKKmTF7BAvMwbhyxKQI4OQY';
////// for merchant id
$formarchid = '17332';
////// for merchant pass
$formarchpass = 'e1hXWxB1UaL61CfraaSgFQmoWmG2cP08';






?>