<?
$db=mysqli_connect('localhost','root','','trx1');
if(!$db){echo "Data Base Not Connected"; }
////////////////////////////////////////








?>